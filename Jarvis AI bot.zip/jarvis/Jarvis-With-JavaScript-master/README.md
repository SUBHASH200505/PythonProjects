# Jarvis-Friday-With-JavaScript

This project doesn't work properly with the current versions of browsers due to privacy issues.

This is A virtual voice Assistant for browsers made using HTML CSS & JAVASCRIPT.
[Project Playlist](https://www.youtube.com/playlist?list=PLWqtZHJOTN49HtkbGvjM8DcsrytltF1kP)
