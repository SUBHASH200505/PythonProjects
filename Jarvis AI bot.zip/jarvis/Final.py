import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import smtplib
import requests
import random
import subprocess
from bs4 import BeautifulSoup

def speak(audio):
    engine = pyttsx3.init()
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = int(datetime.datetime.now().hour)
    if 4 <= hour < 12:
        speak("Good Morning!")
    elif 12 <= hour < 16:
        speak("Good Afternoon!")
    elif 16 <= hour < 20:
        speak("Good Evening!")
    else:
        speak("Good Night!")
    speak("Hey I'm Jarvis!!. I'm your personal assistant to help you out.")
    speak("May I know your name please?")
    name = input("Enter your name:")
    speak(f"Please tell me how may I help you {name}.")

def open_default_app(app_name):
    try:
        subprocess.Popen(app_name, shell=True)
        speak(f"Opening {app_name}...")
    except Exception as e:
        speak("Failed to open app:" + str(e))

def takeCommand():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        print("Recognizing...")
        query = recognizer.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")
        return query.lower()
    except Exception as e:
        print("Say that again please...")
        return "None"

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('your_email@gmail.com', 'your_password')
    server.sendmail('your_email@gmail.com', to, content)
    server.close()

def searchOnYouTube(query):
    url = f"https://www.youtube.com/results?search_query={query}"
    webbrowser.open(url)

def searchOnGoogle(query):
    url = f"https://www.google.com/search?q={query}"
    webbrowser.open(url)

def searchOnAmazon(product):
    url = f"https://www.amazon.com/s?k={product}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    products = soup.find_all('div', {'data-component-type': 's-search-result'})

    if not products:
        speak("No products found.")
        return

    min_price = None
    min_product = None

    for product in products:
        title = product.find('span', {'class': 'a-size-medium'}).text.strip()
        price = product.find('span', {'class': 'a-offscreen'}).text.strip()

        # Remove currency symbols and commas
        price = float(price.replace('$', '').replace(',', ''))

        if min_price is None or price < min_price:
            min_price = price
            min_product = title

    if min_product:
        speak(f"The product with the minimum price is {min_product} priced at ${min_price}.")
    else:
        speak("No product found with a price.")

def getWeatherInfo(city):
    api_key = 'your_openweathermap_api_key'
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"
    response = requests.get(url)
    data = response.json()
    if data['cod'] == '404':
        speak("City not found")
    else:
        weather_desc = data['weather'][0]['description']
        temp = data['main']['temp']
        temp_celsius = round(temp - 273.15, 2)
        speak(f"The weather in {city} is {weather_desc}. The temperature is {temp_celsius} degrees Celsius.")

def tellJoke():
    jokes = [
        'Why did the scarecrow win an award? Because he was outstanding in his field!',
        'Parallel lines have so much in common. It\'s a shame they\'ll never meet.',
        # Add more jokes here if needed
    ]
    joke = random.choice(jokes)
    print(joke)
    speak(joke)

def main():
    wishMe()
    while True:
        query = takeCommand()

        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)

        elif 'play music' in query:
            music_dir = r'C:\music'
            songs = os.listdir(music_dir)
            print(songs)
            os.startfile(os.path.join(music_dir, songs[0]))

        elif 'time' in query:
            strTime = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"The time is {strTime}")

        elif 'send email' in query:
            try:
                speak("What should I say?")
                content = takeCommand()
                to = "recipient_email@example.com"
                sendEmail(to, content)
                speak("Email has been sent!")
            except Exception as e:
                print(e)
                speak("Sorry my friend. I am not able to send this email")

        elif 'search on youtube' in query:
            speak("What do you want to search on YouTube?")
            search_query = takeCommand()
            searchOnYouTube(search_query)

        elif 'search on google' in query:
            speak("What do you want to search on Google?")
            search_query = takeCommand()
            searchOnGoogle(search_query)

        elif 'search on amazon' in query:
            speak("What product do you want to search on Amazon?")
            product = takeCommand()
            searchOnAmazon(product)

        elif 'search minimum price on amazon' in query:
            speak("What product do you want to search for?")
            product = takeCommand()
            searchMinPriceProduct(product)

        elif 'tell me a joke' in query:
            tellJoke()

        elif 'exit' in query:
            speak("Goodbye Sir!")
            exit()

        elif 'make you' in query or 'created you' in query or 'develop you' in query:
            ans_m = "For your information subhash Created me! I give Lot of Thanks to Him"
            print(ans_m)
            speak(ans_m)

        elif "who are you" in query or "about you" in query or "your details" in query:
            about = "I am Jarvis an AI based computer program but I can help you a lot like your close friend! I promise you! Simply try me to give simple command! like playing music or video from your directory I also play video and song from web or online! I can also entertain you so think you Understand me! ok Lets Start"
            print(about)
            speak(about)

        elif "hello" in query or "hello Jarvis" in query:
            hel = "Hello subhash! How May i Help you.."
            print(hel)
            speak(hel)

        elif "your name" in query or "sweet name" in query:
            na_me = "Thanks for Asking my name myself Jarvis"
            print(na_me)
            speak(na_me)

        elif "you feeling" in query:
            print("Feeling Very sweet after meeting with you")
            speak("Feeling Very sweet after meeting with you")

        elif 'shutdown pc' in query:
            speak("Your PC will be shut down soon. Goodbye!!!See you again.")
            os.system('shutdown /s /t 1')

        elif 'notepad' in query:
            open_default_app("notepad")

        elif 'wordpad' in query:
            open_default_app("winword")

        elif 'excel' in query:
            open_default_app("excel")

        elif 'powerpoint' in query:
            open_default_app("powerpnt")

        elif 'paint' in query:
            open_default_app("mspaint")

        elif 'calculator' in query:
            open_default_app("calc")

        else:
            speak("Unsupported command.")

if __name__ == "__main__":
    main()
