import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import smtplib
import requests
import random
import subprocess

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = datetime.datetime.now().hour

    if 4 <= hour < 12:
        speak("Good Morning!")
        
    elif 12 <= hour < 16:
        speak("Good Afternoon!")
        
    elif 16 <= hour < 20:
        speak("Good Evening!")
        
    else:
        speak("Good Night!")

    speak("Hey I'm Jarvis!!. I'm your personal assistant to help you out.")
    speak("May I know your name please?")
    
    name = input("Enter your name:")
    speak("Please tell me how may I help you {}.".format(name))

def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source: #Accessing microphone
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")

    except Exception as e:
        print("Say that again please...")
        return "None"
    
    return query


def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('your_email@gmail.com', 'your_password')
    server.sendmail('your_email@gmail.com', to, content)
    server.close()


def searchOnYouTube(query):
    url = f"https://www.youtube.com/results?search_query={query}"
    webbrowser.open(url)


def searchOnGoogle(query):
    url = f"https://www.google.com/search?q={query}"
    webbrowser.open(url)


def getWeatherInfo(city):
    api_key = 'your_openweathermap_api_key'
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"
    response = requests.get(url)
    data = response.json()

    if data['cod'] == '404':
        speak("City not found")

    else:
        weather_desc = data['weather'][0]['description']
        temp = data['main']['temp']
        temp_celsius = round(temp - 273.15, 2)
        speak(f"The weather in {city} is {weather_desc}. The temperature is {temp_celsius} degrees Celsius.")


def tellJoke():

    # List of jokes
    jokes = [
        'Why did the scarecrow win an award? Because he was outstanding in his field!',
        'Parallel lines have so much in common. It\'s a shame they\'ll never meet.',
        'Why did the bicycle fall over? Because it was two-tired!',
        'I told my wife she was drawing her eyebrows too high. She looked surprised.',
        'What do you call a bear with no teeth? A gummy bear!',
        'Why did the math book look sad? Because it had too many problems.',
        'Why did the tomato turn red? Because it saw the salad dressing!',
        'What do you call a fish with no eyes? Fsh!',
        'Why did the coffee file a police report? It got mugged!',
        'What do you call a snowman with a six-pack? An abdominal snowman!',
        'Why did the golfer bring two pairs of pants? In case he got a hole in one!',
        'Why did the bicycle fall over? It was two-tired!',
        'What do you call a bear with no teeth? A gummy bear!',
        'Why did the scarecrow win an award? Because he was outstanding in his field!',
        'Why did the scarecrow become a successful politician? Because he was outstanding in his field!',
        'Why did the math book look sad? Because it had too many problems.',
        'Why did the tomato turn red? Because it saw the salad dressing!',
        'What do you call a fish with no eyes? Fsh!',
        'Why did the coffee file a police report? It got mugged!',
        'What do you call a snowman with a six-pack? An abdominal snowman!',
        'Why did the golfer bring two pairs of pants? In case he got a hole in one!',
        'Why did the bicycle fall over? It was two-tired!',
        'What do you call a bear with no teeth? A gummy bear!',
        'Why did the scarecrow win an award? Because he was outstanding in his field!',
        'Why did the scarecrow become a successful politician? Because he was outstanding in his field!',
        'Why did the math book look sad? Because it had too many problems.',
        'Why did the tomato turn red? Because it saw the salad dressing!',
        'What do you call a fish with no eyes? Fsh!',
        'Why did the coffee file a police report? It got mugged!',
        'What do you call a snowman with a six-pack? An abdominal snowman!',
        'Why did the golfer bring two pairs of pants? In case he got a hole in one!',
        'Why did the bicycle fall over? It was two-tired!',
        'What do you call a bear with no teeth? A gummy bear!',
        'Why did the scarecrow win an award? Because he was outstanding in his field!',
        'Why did the scarecrow become a successful politician? Because he was outstanding in his field!',
        'Why did the math book look sad? Because it had too many problems.',
        'Why did the tomato turn red? Because it saw the salad dressing!',
        'What do you call a fish with no eyes? Fsh!',
        'Why did the coffee file a police report? It got mugged!']

    joke = random.choice(jokes)
    print(joke, end='\n')
    speak(joke)


wishMe()
if __name__ == "__main__":

    while True:
        query = takeCommand().lower()

        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)

        elif 'youtube' in query:
            webbrowser.open("youtube.com")

        elif 'google' in query:
            webbrowser.open("google.com")

        elif 'stackoverflow' in query:
            webbrowser.open("stackoverflow.com")

        elif 'play store' in query:
            webbrowser.open("https://play.google.com/")

        elif 'chatgpt' in query:
            webbrowser.open("https://www.chatgpt.com/")

        elif 'amazon' in query:
            webbrowser.open("amazon.com")

        elif 'flipkart' in query:
            webbrowser.open("flipkart.com")

        elif 'whatsapp' in query:
            webbrowser.open("https://web.whatsapp.com/")

        elif 'facebook' in query:
            webbrowser.open("https://www.facebook.com/")

        elif 'instagram' in query:
            webbrowser.open("https://www.instagram.com/")

        elif 'play music' in query:
            music_dir = r'C:\music'
            songs = os.listdir(music_dir)

            print(songs)
            os.startfile(os.path.join(music_dir, songs[0]))

        elif 'time' in query:
            strTime = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"The time is {strTime}")

        elif 'send email' in query:
            
            try:
                speak("What should I say?")
                content = takeCommand()
                to = "recipient_email@example.com"
                sendEmail(to, content)
                speak("Email has been sent!")
                
            except Exception as e:
                print(e)
                speak("Sorry my friend. I am not able to send this email")

        elif 'search on youtube' in query:
            speak("What do you want to search on YouTube?")
            search_query = takeCommand()
            searchOnYouTube(search_query)

        elif 'search on google' in query:
            speak("What do you want to search on Google?")
            search_query = takeCommand()
            searchOnGoogle(search_query)

        elif 'weather' in query:
            speak("Which city's weather do you want to know?")
            city = takeCommand()
            getWeatherInfo(city)

        elif 'tell me a joke' in query:
            tellJoke()

        elif 'exit' in query:
            speak("Goodbye Sir!")
            exit()

        elif 'shutdown pc' in query:
            speak("Your PC will be shut down soon. Good Bye!!!See you again.")
            os.system('shutdown /s /t 1')

        elif 'date' in query:
            # Get today's date
            today_date = datetime.date.today()
            # Format the date with day as DD-MM-YYYY
            formatted_date = today_date.strftime("%d-%m-%Y")
            speak("Today's date is ", formatted_date)

        elif 'day' in query:
            today_date = datetime.date.today()
            day = today_date.strftime("%A")
            speak("Today is ", day)

        elif 'open' in query:
            program = query.split("open")[1].strip()
            os.system(f'start {program}')

