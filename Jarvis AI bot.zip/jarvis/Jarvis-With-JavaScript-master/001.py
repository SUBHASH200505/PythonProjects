import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import smtplib
import requests
import random

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)


def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if 0 <= hour < 12:
        speak("Good Morning!")
    elif 12 <= hour < 18:
        speak("Good Afternoon!")
    else:
        speak("Good Evening!")
    speak("I am Jarvis Sir. Please tell me how may I help you Subhash ")


def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")

    except Exception as e:
        print("Say that again please...")
        return "None"
    return query


def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('your_email@gmail.com', 'your_password')  # Replace with your email and password
    server.sendmail('your_email@gmail.com', to, content)
    server.close()


def searchOnYouTube(query):
    url = f"https://www.youtube.com/results?search_query={query}"
    webbrowser.open(url)


def searchOnGoogle(query):
    url = f"https://www.google.com/search?q={query}"
    webbrowser.open(url)


def getWeatherInfo(city):
    api_key = 'your_openweathermap_api_key'  # Replace with your OpenWeatherMap API key
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"
    response = requests.get(url)
    data = response.json()
    if data['cod'] == '404':
        speak("City not found")
    else:
        weather_desc = data['weather'][0]['description']
        temp = data['main']['temp']
        temp_celsius = round(temp - 273.15, 2)
        speak(f"The weather in {city} is {weather_desc}. The temperature is {temp_celsius} degrees Celsius.")


def tellJoke():
    jokes = [
        "Why don't scientists trust atoms? Because they make up everything!",
        "I'm reading a book on anti-gravity. It's impossible to put down!",
        "What do you call fake spaghetti? An impasta!",
        "I told my computer I needed a break, and now it won't stop sending me vacation ads.",
        "Why did the tomato turn red? Because it saw the salad dressing!"
    ]
    joke = random.choice(jokes)
    speak(joke)


if __name__ == "__main__":
    wishMe()
    while True:
        query = takeCommand().lower()

        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")

        elif 'open google' in query:
            webbrowser.open("google.com")

        # Add other commands here...

        elif 'exit' in query:
            speak("Goodbye Sir!")
            exit()
