// Get the audio element for playing sounds
var jIntro = document.getElementById('j_intro');
var turnOn = document.getElementById('turn_on');

// Get the start and stop buttons
var startJarvisBtn = document.getElementById('start_jarvis_btn');
var stopJarvisBtn = document.getElementById('stop_jarvis_btn');

// Get the recognition object
var recognition = new webkitSpeechRecognition();

// Set recognition properties
recognition.continuous = true;
recognition.lang = 'en-IN';

// Event listener for start button
startJarvisBtn.addEventListener('click', function() {
  jIntro.play(); // Play the intro sound
  turnOn.play(); // Play the power up sound
  recognition.start();
  startJarvisBtn.style.display = 'none'; // Hide start button
  stopJarvisBtn.style.display = 'block'; // Show stop button
});

// Event listener for stop button
stopJarvisBtn.addEventListener('click', function() {
  recognition.stop();
  startJarvisBtn.style.display = 'block'; // Show start button
  stopJarvisBtn.style.display = 'none'; // Hide stop button
});

// Event listener for speech recognition
recognition.onresult = function(event) {
  var result = event.results[event.results.length - 1][0].transcript.trim();
  // Process the result here (e.g., send it to your Python code)
  console.log(result); // Example: Log the recognized speech
};

// Event listener for speech recognition error
recognition.onerror = function(event) {
  console.error('Speech recognition error:', event.error);
};

// Event listener for speech recognition end (optional)
recognition.onend = function() {
  console.log('Speech recognition ended');
};
