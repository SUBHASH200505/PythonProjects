from flask import Flask, render_template, request, jsonify
import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import smtplib
import requests
import random

app = Flask(__name__)

# Voice Engine Setup
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = datetime.datetime.now().hour

    if 4 <= hour < 12:
        speak("Good Morning!")
        
    elif 12 <= hour < 16:
        speak("Good Afternoon!")
        
    elif 16 <= hour < 20:
        speak("Good Evening!")
        
    else:
        speak("Good Night!")

    speak("Hey I'm Jarvis!!. I'm your personal assistant to help you out.")
    return "Hey I'm Jarvis! I'm your personal assistant."

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('your_email@gmail.com', 'your_password')
    server.sendmail('your_email@gmail.com', to, content)
    server.close()

def searchOnYouTube(query):
    url = f"https://www.youtube.com/results?search_query={query}"
    webbrowser.open(url)

def searchOnGoogle(query):
    url = f"https://www.google.com/search?q={query}"
    webbrowser.open(url)

def getWeatherInfo(city):
    api_key = 'your_openweathermap_api_key'
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"
    response = requests.get(url)
    data = response.json()

    if data['cod'] == '404':
        speak("City not found")
        return "City not found"
    else:
        weather_desc = data['weather'][0]['description']
        temp = data['main']['temp']
        temp_celsius = round(temp - 273.15, 2)
        weather_info = f"The weather in {city} is {weather_desc}. The temperature is {temp_celsius} degrees Celsius."
        speak(weather_info)
        return weather_info

def tellJoke():
    jokes = [
        'Why did the scarecrow win an award? Because he was outstanding in his field!',
        # Add more jokes here
    ]
    joke = random.choice(jokes)
    speak(joke)
    return joke

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/command', methods=['POST'])
def command():
    query = request.form.get('query').lower()
    
    if 'wikipedia' in query:
        query = query.replace("wikipedia", "")
        results = wikipedia.summary(query, sentences=2)
        speak("According to Wikipedia")
        return jsonify({'response': results})
    
    elif 'youtube' in query:
        searchOnYouTube(query)
        return jsonify({'response': 'Opened YouTube'})
    
    elif 'google' in query:
        searchOnGoogle(query)
        return jsonify({'response': 'Opened Google'})
    
    elif 'weather' in query:
        city = request.form.get('city')
        weather_info = getWeatherInfo(city)
        return jsonify({'response': weather_info})
    
    elif 'joke' in query:
        joke = tellJoke()
        return jsonify({'response': joke})
    
    elif 'email' in query:
        try:
            content = request.form.get('content')
            to = "recipient_email@example.com"
            sendEmail(to, content)
            return jsonify({'response': 'Email sent!'})
        except Exception as e:
            return jsonify({'response': str(e)})

    # Add more command options as needed
    
    return jsonify({'response': 'Command not recognized'})

if __name__ == "__main__":
    app.run(debug=True)
